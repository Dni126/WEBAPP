from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'tu_clave_secreta'  # Cambia esto a una clave secreta más segura en un entorno de producción.

# Ruta de inicio de la aplicación
@app.route('/')
def index():
    return render_template('index.html')

# Ruta de inicio de sesión
@app.route('/login')
def login():
    return render_template('login.html')

# Ruta de autenticación
@app.route('/authenticate', methods=['POST'])
def authenticate():
    usuario = request.form.get('usuario')
    contrasena = request.form.get('contrasena')

    # Verifica las credenciales (en este ejemplo, usuario y contrasena son fijos)
    if usuario == 'usuario' and contrasena == 'contrasena':
        session['usuario_autenticado'] = True
        return redirect(url_for('panel'))
    else:
        return redirect(url_for('login'))

# Ruta del panel de autenticación
@app.route('/panel')
def panel():
    # Verifica si el usuario está autenticado antes de mostrar el panel
    if 'usuario_autenticado' in session and session['usuario_autenticado']:
        return "¡Bienvenido al Panel de Autenticación!"
    else:
        return redirect(url_for('login'))

# Ruta de cierre de sesión
@app.route('/logout')
def logout():
    # Cierra la sesión del usuario
    session.pop('usuario_autenticado', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
