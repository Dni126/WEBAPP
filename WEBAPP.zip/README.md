pip install virtualenv
virtualenv env

pip install flask

export FLASK_APP=app
flask run